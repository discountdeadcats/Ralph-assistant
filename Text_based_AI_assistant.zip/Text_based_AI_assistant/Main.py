import os
from anthropic import Anthropic
from openai import OpenAI

# Set up API keys
anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY")
openai_api_key = os.environ.get("OPENAI_API_KEY")

# Initialize clients
anthropic = Anthropic(api_key=anthropic_api_key)
openai_client = OpenAI(api_key=openai_api_key)

def anthropic_response(query):
    try:
        response = anthropic.messages.create(
            model="claude-3-sonnet-20240229",
            max_tokens=300,
            messages=[
                {"role": "user", "content": query}
            ]
        )
        return response.content[0].text
    except Exception as e:
        return f"An error occurred with the Anthropic API: {str(e)}"

def openai_response(query, model):
    try:
        response = openai_client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": query}
            ]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"An error occurred with the OpenAI API: {str(e)}"

def main():
    print("Welcome to the AI Assistant Selector!")
    print("Choose your AI assistant:")
    print("1. Claude 3.5 Sonnet (Anthropic)")
    print("2. GPT-4 (OpenAI)")
    print("3. GPT-4 Turbo (OpenAI)")

    while True:
        choice = input("Enter your choice (1-3), or 'q' to quit: ")
        
        if choice.lower() == 'q':
            print("Thank you for using the AI Assistant Selector. Goodbye!")
            break
        
        if choice not in ['1', '2', '3']:
            print("Invalid choice. Please enter 1, 2, 3, or 'q' to quit.")
            continue
        
        query = input("Enter your query: ")
        
        if choice == '1':
            print(anthropic_response(query))
        elif choice == '2':
            print(openai_response(query, "gpt-4"))
        else:
            print(openai_response(query, "gpt-4-turbo-preview"))

if __name__ == "__main__":
    if not anthropic_api_key or not openai_api_key:
        print("Please set the ANTHROPIC_API_KEY and OPENAI_API_KEY environment variables.")
    else:
        main()